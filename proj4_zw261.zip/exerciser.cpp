#include "exerciser.h"

void exercise(connection *C)
{
//    query1(C, 1, 35, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
//    query1(C, 1, 35, 40, 1, 13, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
//    query1(C, 1, 35, 40, 1, 13, 15, 0, 0, 0, 0, 0, 0, 1, 1.0, 1.2, 0, 0, 0);
//    query2(C, "LightBlue");
//    query2(C, "DarkBlue");
//    query3(C, "Duke");
    query4(C, "NC", "DarkBlue");
//    query5(C, 10);
//    add_player(C, 1, 1, "Zhigang", "Wei",34, 19, 4, 3, 1.7, 0.4);
//    add_color(C, "White");
//    add_state(C, "IA");
//    add_team(C, "Duke_NC", 1, 5, 11, 7);

}
